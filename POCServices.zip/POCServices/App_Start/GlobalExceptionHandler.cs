﻿namespace POCServices
{
    internal class GlobalExceptionHandler
    {
        public GlobalExceptionHandler()
        {
        }
    }
}